package com.zia.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.zia.ai.settings.SettingsRepository
import com.zia.ai.settings.ZiaSettings
import com.zia.ai.ui.home.HomeScreen
import com.zia.ai.ui.settings.SettingsScreen
import com.zia.ai.ui.theme.ZiaTheme
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        tts = TextToSpeech(this, this)
        val repo = SettingsRepository(applicationContext)
        setContent {
            val settings by repo.settings.collectAsState(initial = ZiaSettings())
            ZiaTheme(settings.theme) {
                val nav = rememberNavController()
                val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
                val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                    val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                    if (!text.isNullOrBlank()) onSpeechResult?.invoke(text)
                }
                LaunchedEffect(settings.speechSpeed, settings.language) {
                    tts?.setSpeechRate(settings.speechSpeed)
                    tts?.language = when (settings.language.name) {
                        "Hindi" -> Locale("hi", "IN")
                        "English" -> Locale.US
                        else -> Locale("en", "IN")
                    }
                }
                NavHost(navController = nav, startDestination = "home") {
                    composable("home") {
                        HomeScreen(
                            repo = repo,
                            onOpenSettings = { nav.navigate("settings") },
                            onSpeak = { speak(it, settings) },
                            onListen = {
                                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                    micPermission.launch(Manifest.permission.RECORD_AUDIO)
                                } else {
                                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, when (settings.language.name) {
                                            "Hindi" -> "hi-IN"; "English" -> "en-US"; else -> "en-IN"
                                        })
                                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Zia ko bolo…")
                                    }
                                    runCatching { speechLauncher.launch(intent) }
                                }
                            },
                            setSpeechReceiver = { receiver -> onSpeechResult = receiver }
                        )
                    }
                    composable("settings") { SettingsScreen(repo) { nav.popBackStack() } }
                }
            }
        }
    }

    private var onSpeechResult: ((String) -> Unit)? = null

    private fun speak(text: String, settings: ZiaSettings) {
        if (!ttsReady) return
        tts?.setSpeechRate(settings.speechSpeed)
        val locale = when (settings.language.name) {
            "Hindi" -> Locale("hi", "IN")
            "English" -> Locale.US
            else -> Locale("en", "IN")
        }
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zia-response")
    }

    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); tts = null; super.onDestroy() }
}
