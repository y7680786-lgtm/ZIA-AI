package com.zia.ai.ui.home

import android.content.Context
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zia.ai.assistant.GeminiClient
import com.zia.ai.assistant.PhoneActions
import com.zia.ai.settings.SettingsRepository
import com.zia.ai.settings.ZiaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class ChatLine(val who: String, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repo: SettingsRepository,
    onOpenSettings: () -> Unit,
    onSpeak: (String) -> Unit,
    onListen: () -> Unit,
    setSpeechReceiver: (((String) -> Unit) -> Unit)
) {
    val context = LocalContext.current
    val settings by repo.settings.collectAsState(initial = ZiaSettings())
    val scope = rememberCoroutineScope()
    val lines = remember { mutableStateListOf(ChatLine("Zia", "Hi! Main Zia hoon. Mujhse Hinglish mein baat karo, ya koi command do.")) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }
    var error by remember { mutableStateOf<String?>(null) }

    fun send(raw: String) {
        val message = raw.trim()
        if (message.isBlank() || busy) return
        input = ""
        lines.add(ChatLine("You", message))
        val actionResult = runCatching { PhoneActions.run(context, message) }.getOrNull()
        if (actionResult != null) {
            lines.add(ChatLine("Zia", actionResult))
            onSpeak(actionResult)
            return
        }
        if (message.lowercase() in listOf("stop", "chup", "stop speaking", "bolna band karo")) {
            lines.add(ChatLine("Zia", "Theek hai, main ruk gayi."))
            return
        }
        if (settings.apiKey.isBlank()) {
            val reply = "Gemini se baat karne ke liye Settings mein Gemini API key add karo. Tab tak main YouTube search aur supported app-opening commands kar sakti hoon."
            lines.add(ChatLine("Zia", reply))
            onSpeak(reply)
            return
        }
        busy = true
        status = "Thinking…"
        error = null
        scope.launch {
            try {
                val history = lines.dropLast(1).takeLast(10).map { it.who to it.text }
                val answer = withContext(Dispatchers.IO) {
                    GeminiClient.ask(settings.apiKey, settings.model, settings.personality + "\nPreferred language: " + settings.language.label, history, message)
                }
                lines.add(ChatLine("Zia", answer))
                onSpeak(answer)
                status = "Ready"
            } catch (e: Exception) {
                val reply = e.message ?: "Connection error. Internet aur Gemini API settings check karo."
                error = reply
                lines.add(ChatLine("Zia", "Maaf karna, $reply"))
                status = "Error"
            } finally { busy = false }
        }
    }

    setSpeechReceiver { spoken -> send(spoken) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ZIA AI", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                    Text("PERSONAL ASSISTANT • $status", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                } },
                actions = { IconButton(onClick = onOpenSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings") } }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 5.dp) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onListen, enabled = !busy) { Icon(Icons.Default.Mic, contentDescription = "Speak", tint = MaterialTheme.colorScheme.primary) }
                    Box(Modifier.weight(1f).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(24.dp)).padding(horizontal = 14.dp, vertical = 12.dp)) {
                        if (input.isEmpty()) Text("Zia ko message bhejo…", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
                        BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface))
                    }
                    IconButton(onClick = { send(input) }, enabled = input.isNotBlank() && !busy) { Icon(Icons.Default.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.primary) }
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Box(Modifier.fillMaxWidth().height(170.dp), contentAlignment = Alignment.Center) { ZiaOrb() }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Suggestion("YouTube kholo", Modifier.weight(1f)) { send("YouTube kholo") }
                Suggestion("Instagram kholo", Modifier.weight(1f)) { send("Instagram kholo") }
                Suggestion("Hello Zia", Modifier.weight(1f)) { send("Hello Zia") }
            }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                reverseLayout = false,
                contentPadding = PaddingValues(bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(lines) { line ->
                    val mine = line.who == "You"
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                        Text(line.who, style = MaterialTheme.typography.labelSmall, color = if (mine) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary)
                        Surface(
                            color = if (mine) MaterialTheme.colorScheme.secondary.copy(alpha = .18f) else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(16.dp)
                        ) { Text(line.text, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurface) }
                    }
                }
                if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            }
        }
    }
}

@Composable
private fun Suggestion(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)) {
        Text(text, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun ZiaOrb() {
    val transition = rememberInfiniteTransition(label = "orb")
    val scale by transition.animateFloat(
        initialValue = .90f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale"
    )
    Canvas(Modifier.size(150.dp)) {
        val r = size.minDimension * .36f * scale
        drawCircle(brush = Brush.radialGradient(listOf(Color(0xFF22D3EE).copy(alpha = .55f), Color(0xFF7C3AED).copy(alpha = .2f), Color.Transparent)), radius = r * 1.8f)
        drawCircle(brush = Brush.linearGradient(listOf(Color(0xFF22D3EE), Color(0xFF7C3AED))), radius = r, style = Stroke(width = 3.dp.toPx()))
        drawCircle(color = Color(0xFF22D3EE).copy(alpha = .75f), radius = r * .62f)
        drawCircle(color = Color(0xFF05070F), radius = r * .40f)
    }
}
