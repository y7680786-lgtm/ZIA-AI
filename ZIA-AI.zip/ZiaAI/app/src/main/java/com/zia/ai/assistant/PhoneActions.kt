package com.zia.ai.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import java.net.URLEncoder

object PhoneActions {
    fun run(context: Context, text: String): String? {
        val q = text.trim()
        val lower = q.lowercase()
        if (lower.contains("youtube") && listOf("play", "chala", "gana", "song", "search", "kholo", "open").any { lower.contains(it) }) {
            val query = q.replace(Regex("(?i)zia[, ]*"), "")
                .replace(Regex("(?i)youtube( par| pe)?"), "")
                .replace(Regex("(?i)(gaana|gana|song|songs|chalao|chala do|play|search|search karo|kholo|open)"), "")
                .trim().ifBlank { "trending songs" }
            val url = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8")
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "YouTube par \"$query\" search kar diya. Video select karke play kar lo."
        }
        if (lower.contains("wifi") && (lower.contains("setting") || lower.contains("kholo") || lower.contains("open"))) {
            context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Wi-Fi settings khol di."
        }
        if (lower.contains("bluetooth") && (lower.contains("setting") || lower.contains("kholo") || lower.contains("open"))) {
            context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Bluetooth settings khol di."
        }
        val apps = listOf(
            Triple("instagram", "com.instagram.android", "Instagram"),
            Triple("instagram lite", "com.instagram.lite", "Instagram Lite"),
            Triple("telegram", "org.telegram.messenger", "Telegram"),
            Triple("whatsapp", "com.whatsapp", "WhatsApp"),
            Triple("chrome", "com.android.chrome", "Chrome"),
            Triple("youtube music", "com.google.android.apps.youtube.music", "YouTube Music"),
            Triple("youtube", "com.google.android.youtube", "YouTube"),
            Triple("calculator", "com.google.android.calculator", "Calculator")
        )
        val launchIntent = lower.contains("kholo") || lower.contains("open") || lower.contains("launch")
        if (launchIntent) {
            val found = apps.firstOrNull { lower.contains(it.first) }
            if (found != null) {
                val intent = context.packageManager.getLaunchIntentForPackage(found.second)
                if (intent != null) {
                    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return "${found.third} open kar diya."
                }
                if (found.first == "youtube") {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return "YouTube browser mein khol diya."
                }
                return "${found.third} installed nahi mila. App install karke dobara try karo."
            }
        }
        if (lower.contains("settings") || lower.contains("setting kholo") || lower.contains("phone settings")) {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Phone settings khol di."
        }
        if (lower.contains("google") && (lower.contains("search") || lower.contains("dhundo") || lower.contains("dhoondo"))) {
            val url = "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Google search khol diya."
        }
        return null
    }
}
