package com.zia.ai.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    fun ask(apiKey: String, model: String, systemPrompt: String, history: List<Pair<String, String>>, prompt: String): String {
        require(apiKey.isNotBlank()) { "Gemini API key add karo: Settings > Gemini API Key." }
        val contents = JSONArray()
        val recent = history.takeLast(8)
        recent.forEach { (role, text) ->
            val part = JSONObject().put("text", text)
            contents.put(JSONObject().put("role", if (role == "Zia") "model" else "user")
                .put("parts", JSONArray().put(part)))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 2048))
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                val detail = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IllegalStateException("Gemini API error ($code): ${detail ?: response.take(250)}")
            }
            val root = JSONObject(response)
            val candidates = root.optJSONArray("candidates") ?: throw IllegalStateException("Gemini ne response nahi diya.")
            val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw IllegalStateException("Gemini response khaali hai.")
            val result = buildString {
                for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
            }.trim()
            if (result.isBlank()) throw IllegalStateException("Gemini ka jawab khaali tha.")
            return result
        } finally {
            connection.disconnect()
        }
    }
}
