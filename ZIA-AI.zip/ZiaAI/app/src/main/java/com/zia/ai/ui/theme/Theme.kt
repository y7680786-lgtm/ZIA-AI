package com.zia.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.zia.ai.settings.AppTheme

private val DarkColors = darkColorScheme(
    primary = Color(0xFF22D3EE), secondary = Color(0xFFA855F7), tertiary = Color(0xFF3B82F6),
    background = Color(0xFF05070F), surface = Color(0xFF0D1220), surfaceVariant = Color(0xFF151C30),
    onBackground = Color(0xFFE6F1FF), onSurface = Color(0xFFE6F1FF)
)
private val LightColors = lightColorScheme(
    primary = Color(0xFF0891B2), secondary = Color(0xFF7C3AED), tertiary = Color(0xFF2563EB),
    background = Color(0xFFF5F8FF), surface = Color.White, surfaceVariant = Color(0xFFE8EEFB)
)

@Composable
fun ZiaTheme(theme: AppTheme, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (theme == AppTheme.Light) LightColors else DarkColors, content = content)
}
