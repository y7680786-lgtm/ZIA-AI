package com.zia.ai.settings

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "zia_settings")

enum class AppLanguage(val label: String) {
    Hinglish("Hinglish"), Hindi("हिन्दी"), English("English")
}
enum class AppTheme(val label: String) { Dark("Dark"), Light("Light") }

const val DEFAULT_PERSONALITY =
    "You are Zia, a friendly, caring, playful female AI assistant. Speak naturally, usually in Hinglish. Be helpful and honest. Never pretend to be a real human. Keep answers concise unless detail is requested."

data class ZiaSettings(
    val language: AppLanguage = AppLanguage.Hinglish,
    val theme: AppTheme = AppTheme.Dark,
    val speechSpeed: Float = 1.0f,
    val personality: String = DEFAULT_PERSONALITY,
    val apiKey: String = "",
    val model: String = "gemini-2.0-flash"
)

class SettingsRepository(private val context: Context) {
    private object Keys {
        val language = stringPreferencesKey("language")
        val theme = stringPreferencesKey("theme")
        val speed = floatPreferencesKey("speech_speed")
        val personality = stringPreferencesKey("personality")
        val apiKey = stringPreferencesKey("gemini_api_key")
        val model = stringPreferencesKey("gemini_model")
    }

    val settings: Flow<ZiaSettings> = context.dataStore.data.map { it.toSettings() }

    private fun Preferences.toSettings() = ZiaSettings(
        language = this[Keys.language]?.let { runCatching { AppLanguage.valueOf(it) }.getOrNull() } ?: AppLanguage.Hinglish,
        theme = this[Keys.theme]?.let { runCatching { AppTheme.valueOf(it) }.getOrNull() } ?: AppTheme.Dark,
        speechSpeed = this[Keys.speed] ?: 1.0f,
        personality = this[Keys.personality] ?: DEFAULT_PERSONALITY,
        apiKey = this[Keys.apiKey] ?: "",
        model = this[Keys.model] ?: "gemini-2.0-flash"
    )

    suspend fun setLanguage(v: AppLanguage) { context.dataStore.edit { it[Keys.language] = v.name } }
    suspend fun setTheme(v: AppTheme) { context.dataStore.edit { it[Keys.theme] = v.name } }
    suspend fun setSpeechSpeed(v: Float) { context.dataStore.edit { it[Keys.speed] = v } }
    suspend fun setPersonality(v: String) { context.dataStore.edit { it[Keys.personality] = v } }
    suspend fun setApiKey(v: String) { context.dataStore.edit { it[Keys.apiKey] = v.trim() } }
    suspend fun setModel(v: String) { context.dataStore.edit { it[Keys.model] = v.trim() } }
}
