package com.zia.ai.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.zia.ai.assistant.GeminiClient
import com.zia.ai.settings.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(repo: SettingsRepository, onBack: () -> Unit) {
    val s by repo.settings.collectAsState(initial = ZiaSettings())
    val scope = rememberCoroutineScope()
    var keyDraft by remember(s.apiKey) { mutableStateOf(s.apiKey) }
    var modelDraft by remember(s.model) { mutableStateOf(s.model) }
    var personalityDraft by remember(s.personality) { mutableStateOf(s.personality) }
    var keyVisible by remember { mutableStateOf(false) }
    var testStatus by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Zia Settings") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
        })
    }) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Text("Gemini AI Brain", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                Text("API key tumhari device ki app settings mein save hoti hai. Public/shared device par key save na karo. Production apps ke liye secure backend recommended hai.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = keyDraft, onValueChange = { keyDraft = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Gemini API key") },
                    visualTransformation = if (keyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = { IconButton(onClick = { keyVisible = !keyVisible }) {
                        Icon(if (keyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = "Show or hide key")
                    } },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = modelDraft, onValueChange = { modelDraft = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Gemini model") }, singleLine = true)
                Text("Example model: gemini-2.0-flash. Use a model name currently available to your API key.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { scope.launch { repo.setApiKey(keyDraft); repo.setModel(modelDraft); testStatus = "Settings saved." } }) { Text("Save") }
                    OutlinedButton(enabled = !testing, onClick = {
                        testing = true
                        testStatus = "Testing connection…"
                        scope.launch {
                            try {
                                repo.setApiKey(keyDraft); repo.setModel(modelDraft)
                                val answer = withContext(Dispatchers.IO) {
                                    GeminiClient.ask(keyDraft, modelDraft, "Reply briefly.", emptyList(), "Reply with: Zia connection successful.")
                                }
                                testStatus = "Connected! ${answer.take(120)}"
                            } catch (e: Exception) {
                                testStatus = e.message ?: "Connection failed. Check internet, model, and API key."
                            } finally { testing = false }
                        }
                    }) { Text("Test connection") }
                }
                if (testStatus.isNotBlank()) Text(testStatus, color = if (testStatus.startsWith("Connected")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary)
            }
            item {
                Text("Language", style = MaterialTheme.typography.titleLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppLanguage.values().forEach { language ->
                        FilterChip(selected = s.language == language, onClick = { scope.launch { repo.setLanguage(language) } }, label = { Text(language.label) })
                    }
                }
            }
            item {
                Text("Theme", style = MaterialTheme.typography.titleLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppTheme.values().forEach { theme ->
                        FilterChip(selected = s.theme == theme, onClick = { scope.launch { repo.setTheme(theme) } }, label = { Text(theme.label) })
                    }
                }
            }
            item {
                Text("Voice speed: ${"%.1f".format(s.speechSpeed)}x", style = MaterialTheme.typography.titleLarge)
                Slider(value = s.speechSpeed, onValueChange = { value -> scope.launch { repo.setSpeechSpeed(value) } }, valueRange = 0.7f..1.4f)
            }
            item {
                Text("Zia personality", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(value = personalityDraft, onValueChange = { personalityDraft = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp), label = { Text("System prompt") })
                Button(onClick = { scope.launch { repo.setPersonality(personalityDraft); testStatus = "Personality saved." } }) { Text("Save personality") }
                Text("Tip: API key ko kisi ke saath share mat karna. Agar key leak ho jaye to provider console se revoke kar dena.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
