# ZIA AI — Android starter app

ZIA AI is a Kotlin + Jetpack Compose Android assistant with:
- Gemini API chat (configure your own key in Settings)
- Hindi / Hinglish / English preference
- Android text-to-speech and speech recognition
- Supported app launching
- YouTube search
- Wi-Fi, Bluetooth, and phone Settings shortcuts
- Dark/light theme and editable assistant personality

## Important limitations
- This starter does not have unrestricted screen tapping. Android requires a user-enabled Accessibility Service and app-specific implementation for UI automation.
- YouTube searches open search results; selecting/playing a result may require the user.
- The API key is stored in app preferences on the device. This is suitable only for a personal prototype, not a production app. A secure backend is recommended for release.
- Some package names and actions vary by Android version and installed apps.
- The Gemini model name must be available to your API key and region.

## Build in Termux (Android phone)
1. Install Termux from a trusted source and update packages:
   `pkg update && pkg upgrade`
2. Install basic tools:
   `pkg install openjdk-17 gradle unzip`
3. Extract the ZIP:
   `unzip ZiaAI-full-source.zip`
   `cd ZiaAI`
4. You also need a working Android SDK with platform 34 and build-tools 34.0.0 configured in `ANDROID_HOME`. Termux does not automatically include the Android SDK. If you have installed SDK command-line tools, set:
   `export ANDROID_HOME=$HOME/Android/Sdk`
   `export PATH=$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin`
5. Build:
   `gradle assembleDebug`
6. APK output:
   `app/build/outputs/apk/debug/app-debug.apk`

If Gradle reports that Android SDK is missing, install/configure Android SDK platform 34 and build-tools 34.0.0 first. Building on a computer with Android Studio is generally easier.

## First launch
1. Open ZIA AI.
2. Go to Settings.
3. Add your Gemini API key and save.
4. Tap Test connection.
5. Return to chat and ask Zia something.

## Example commands
- `YouTube kholo`
- `YouTube par Arijit Singh ke gaane search karo`
- `Instagram kholo`
- `Telegram kholo`
- `Wi-Fi settings kholo`
- `Bluetooth settings kholo`
- `Google search Python tutorial`

App launching is limited to the app list and Android capabilities. This version is a working starter, not a full JARVIS-level automation system.
